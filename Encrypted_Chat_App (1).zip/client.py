
import socket
import threading
import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.padding import PKCS7
from cryptography.hazmat.backends import default_backend

HOST = "127.0.0.1"
PORT = 5000

SECRET_KEY = b"12345678901234567890123456789012"

def encrypt_message(message, key):
    iv = os.urandom(16)

    padder = PKCS7(128).padder()
    padded_data = padder.update(message.encode()) + padder.finalize()

    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()

    ciphertext = encryptor.update(padded_data) + encryptor.finalize()
    return iv + ciphertext

def decrypt_message(ciphertext, key):
    iv = ciphertext[:16]
    actual_cipher = ciphertext[16:]

    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()

    padded_message = decryptor.update(actual_cipher) + decryptor.finalize()

    unpadder = PKCS7(128).unpadder()
    message = unpadder.update(padded_message) + unpadder.finalize()

    return message.decode()

def receive_messages(client_socket):
    while True:
        try:
            encrypted_message = client_socket.recv(4096)
            message = decrypt_message(encrypted_message, SECRET_KEY)
            print(f"\nReceived: {message}")
        except:
            print("Disconnected from server")
            break

def send_messages(client_socket):
    while True:
        message = input("You: ")
        encrypted_message = encrypt_message(message, SECRET_KEY)
        client_socket.send(encrypted_message)

def start_client():
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((HOST, PORT))

    threading.Thread(target=receive_messages, args=(client,), daemon=True).start()
    send_messages(client)

start_client()
