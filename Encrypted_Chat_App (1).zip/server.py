
import socket
import threading
import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.padding import PKCS7
from cryptography.hazmat.backends import default_backend

HOST = "127.0.0.1"
PORT = 5000

SECRET_KEY = b"12345678901234567890123456789012"

clients = []

def encrypt_message(message, key):
    iv = os.urandom(16)
    
    padder = PKCS7(128).padder()
    padded_data = padder.update(message.encode()) + padder.finalize()

    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()

    ciphertext = encryptor.update(padded_data) + encryptor.finalize()
    return iv + ciphertext

def decrypt_message(ciphertext, key):
    iv = ciphertext[:16]
    actual_cipher = ciphertext[16:]

    cipher = Cipher(algorithms.AES(key), modes.CBC(iv), backend=default_backend())
    decryptor = cipher.decryptor()

    padded_message = decryptor.update(actual_cipher) + decryptor.finalize()

    unpadder = PKCS7(128).unpadder()
    message = unpadder.update(padded_message) + unpadder.finalize()

    return message.decode()

def broadcast(message, sender):
    for client in clients:
        if client != sender:
            client.send(message)

def handle_client(client_socket, address):
    print(f"[NEW CONNECTION] {address} connected")
    
    while True:
        try:
            encrypted_message = client_socket.recv(4096)
            if not encrypted_message:
                break

            message = decrypt_message(encrypted_message, SECRET_KEY)

            log_message = f"{address}: {message}"
            print(log_message)

            with open("chat_log.txt", "a") as f:
                f.write(log_message + "\n")

            broadcast(encrypted_message, client_socket)

        except:
            break

    print(f"[DISCONNECTED] {address}")
    clients.remove(client_socket)
    client_socket.close()

def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen()

    print(f"[SERVER STARTED] {HOST}:{PORT}")

    while True:
        client_socket, address = server.accept()
        clients.append(client_socket)

        thread = threading.Thread(target=handle_client, args=(client_socket, address))
        thread.start()

start_server()
