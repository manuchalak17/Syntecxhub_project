
import socket
import os
import hmac
import hashlib

HOST = "127.0.0.1"
PORT = 6000
BUFFER_SIZE = 4096

HMAC_KEY = b"hmac_secret_key"

def calculate_hmac(data):
    return hmac.new(HMAC_KEY, data, hashlib.sha256).digest()

def upload_file(filename):
    client = socket.socket()
    client.connect((HOST, PORT))

    client.send(f"UPLOAD {os.path.basename(filename)}".encode())

    with open(filename, "rb") as f:
        file_data = f.read()

    client.sendall(file_data + b"<END>")
    client.send(calculate_hmac(file_data))

    print(client.recv(1024).decode())
    client.close()

def download_file(filename):
    client = socket.socket()
    client.connect((HOST, PORT))

    client.send(f"DOWNLOAD {filename}".encode())

    file_data = b""
    while True:
        chunk = client.recv(BUFFER_SIZE)
        if chunk.endswith(b"<END>"):
            file_data += chunk[:-5]
            break
        file_data += chunk

    recv_hmac = client.recv(32)

    if recv_hmac == calculate_hmac(file_data):
        with open("downloaded_" + filename, "wb") as f:
            f.write(file_data)
        print("Download successful")
    else:
        print("Integrity check failed")

    client.close()

choice = input("Upload or Download (u/d): ").lower()

if choice == "u":
    filename = input("Enter file path: ")
    upload_file(filename)

elif choice == "d":
    filename = input("Enter file name: ")
    download_file(filename)
