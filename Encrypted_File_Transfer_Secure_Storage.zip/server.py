
import socket
import os
import hmac
import hashlib
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

HOST = "127.0.0.1"
PORT = 6000
BUFFER_SIZE = 4096

AES_KEY = b"12345678901234567890123456789012"
HMAC_KEY = b"hmac_secret_key"

STORAGE_DIR = "secure_storage"
os.makedirs(STORAGE_DIR, exist_ok=True)

def encrypt_data(data):
    iv = os.urandom(16)
    cipher = Cipher(algorithms.AES(AES_KEY), modes.CFB(iv))
    encryptor = cipher.encryptor()
    return iv + encryptor.update(data)

def decrypt_data(data):
    iv = data[:16]
    encrypted = data[16:]
    cipher = Cipher(algorithms.AES(AES_KEY), modes.CFB(iv))
    decryptor = cipher.decryptor()
    return decryptor.update(encrypted)

def calculate_hmac(data):
    return hmac.new(HMAC_KEY, data, hashlib.sha256).digest()

def handle_client(client):
    command = client.recv(1024).decode()

    if command.startswith("UPLOAD"):
        filename = command.split()[1]
        filepath = os.path.join(STORAGE_DIR, filename)

        file_data = b""
        while True:
            chunk = client.recv(BUFFER_SIZE)
            if chunk.endswith(b"<END>"):
                file_data += chunk[:-5]
                break
            file_data += chunk

        recv_hmac = client.recv(32)

        if recv_hmac == calculate_hmac(file_data):
            encrypted_data = encrypt_data(file_data)
            with open(filepath, "wb") as f:
                f.write(encrypted_data)
            client.send(b"UPLOAD SUCCESS")
        else:
            client.send(b"HMAC FAILED")

    elif command.startswith("DOWNLOAD"):
        filename = command.split()[1]
        filepath = os.path.join(STORAGE_DIR, filename)

        if not os.path.exists(filepath):
            client.send(b"FILE NOT FOUND")
            client.close()
            return

        with open(filepath, "rb") as f:
            encrypted_data = f.read()

        decrypted_data = decrypt_data(encrypted_data)
        file_hmac = calculate_hmac(decrypted_data)

        client.sendall(decrypted_data + b"<END>")
        client.send(file_hmac)

    client.close()

def start_server():
    server = socket.socket()
    server.bind((HOST, PORT))
    server.listen()

    print("Secure File Server Running...")

    while True:
        client, _ = server.accept()
        handle_client(client)

start_server()
